#ifndef XMLTV_H_
# define XMLTV_H_                       1

# include "dvb/dvb.h"

void xmltv_write_event(event_t *event, void *data);

#endif /*!XMLTV_H_ */
