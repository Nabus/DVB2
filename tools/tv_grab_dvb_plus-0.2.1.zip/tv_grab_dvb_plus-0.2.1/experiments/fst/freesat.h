#ifndef FREESAT_H
#define FREESAT_H

#include <sys/types.h>

extern char *freesat_huffman_decode(const unsigned char *compressed, size_t size); 

#endif
